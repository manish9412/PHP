<?php 
include ("includes/connection.php");

if(isset($_POST['submit']))
{
	if (!empty($_POST['email']) && !empty($_POST['password']))
	{
		$email = $_POST['email'];
		$password = $_POST['password'];
		$password = md5('password');

		$sql = "insert into sign_in(email,password) values('$email','$password')";
		$run = mysqli_query($conn,$sql) or die(mysqli_error());

		if ($run)
		{
			# echo "Form Submitted Successfully";
		}
		else
		{
			echo "Form not submitted";
		}
	}
else
{
	echo "All fields required";
}

}


if(isset($_POST['create']))
{
	if (!empty($_POST['Name']) && !empty($_POST['Email']) && !empty($_POST['Password']) && !empty($_POST['CPassword']))
	{
		$name = $_POST['Name'];
		$email = $_POST['Email'];
		$password = $_POST['Password'];
		$password = md5('Password');
		$cpassword = $_POST['CPassword'];

		$sql1 = "insert into sign_up(Name,Email,Password,CPassword) values('$name','$email','$password','$cpassword')";
		$run2 = mysqli_query($conn,$sql1) or die(mysqli_error());

		if ($run2)
		{
			# echo "Form Submitted Successfully";
		}
		else
		{
			echo "Form not submitted";
		}
	}
else
{
	echo "All fields required";
}

}

 
 

 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>Data Page</title>
 	<meta http-equiv="X-UA-Compatible" content="ie-edge">
 	<meta http-equiv="refresh" content="2; url=logged.php">
 </head>
 <body>

 <h2 class="display-2"> Successfully Submitted <br>  Please Wait... </h2>
 <script src="assets/js/script.js"></script>
 </body>
 </html>