<?php

if ($_SERVER["REQUEST_METHOD "] =="POST" )
{	$showAlert = false;
	include 'includes/dbconnect.php';
	$username = $_POST["username"];
	$password = $_POST["password"];
	$cpassword = $_POST["cpassword"];
	$exists == false;
	if (($password == $cpassword) && ($exists == false))
	{
		$sql = "INSERT INTO `users` ( `email`, `password`, `dt`) VALUES ('$username', 'password',current_timestamp())"; 
		$result = mysqli_query($conn,$sql);
		if ($result == TRUE)
		{
			$showAlert = false;
		}
	}
}
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
 
</style>
</head>
<body>
<?php
	require 'includes/nav.php';
?>
<?php
$showAlert = false;

if ($showAlert) 
{
	echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
	  <strong>Success..!! </strong> Your account is now created. Now you can now login
	  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
	    <span aria-hidden="true">&times;</span>
	  </button>
	</div>';
}
?>
<div class="container">
  <h1 class="text-center">Create Account</h1>

  <form action="/loginsystem/signup.php" method="post">
  <div class="form-group">
    <label for="username">Email </label>
    <input type="email" class="form-control" id="username" aria-describedby="emailHelp" name="username">
    
  </div>
  <div class="form-group">
    <label for="password">Password</label>
    <input type="password" class="form-control" name="password" id="password" >  
</div>
  <div class="form-group">
    <label for="cpassword">Confirm Password</label>
    <input type="password" class="form-control" id="cpassword" name="cpassword " >
  	<small id="emailHelp" class="form-text text-muted">Check the password again.</small>
  </div>
  <button type="submit" class="btn btn-primary">Signup</button>
</form>
</div>


</body>
</html>